const config = require("./config.json");

let permission =
  {
    Stf: 0, //anyone can use this command!
    GUILD_ONLY: 1, //anyone can use this command, but only in a guild!
  //intentionally leaving room for other, future permission here
    ADMIN_ONLY: 3, //only administrators can use this command!
    OWNER_ONLY: 4 //only the bot owner can use this command!
  };
module.exports = permission;
module.exports.checkPermission = (message, command) => {
  if(command.permission === Stf.apagar) return true;
}