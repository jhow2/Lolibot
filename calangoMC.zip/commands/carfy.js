const Discord = require("discord.js");

module.exports.run = (bot, message, args) => {

    function checkBots(guild) {
        let botCount = 0; // This is value that we will return
        guild.members.forEach(member => { // We are executing this code for every user that is in guild
          if(member.user.bot) botCount++; // If user is a bot, add 1 to botCount value
        });
        return Message.Channel.send("Você não podes ultilizar este comando Aqui bobinho")
        return botCount; // Return amount of bots
      }

    var embed = new Discord.RichEmbed()
        .setTitle("Funções Do carfy bot!!!")
        .setDescription("Use Somente em #⚙┋comandos Os Comandos Meu Querido(a)")
        .addField("/perfil", "Veja um histórico de nome de usuário, skin, uuid e muito mais/ profile [nome de usuário Minecraft]!")
        .addField("/servidor", "Solicitar informações sobre um servidor multiplayer do Minecraft Java Edition	/ servidor [endereço do servidor]")
        .addField("/status"," Ver status de serviço do Minecraft e vendas de jogos	/status")




        .setColor("#df41ca")
        .setThumbnail(bot.user.avatarURL)
        message.channel.sendEmbed(embed);
        if(message.deletable) message.delete();

}