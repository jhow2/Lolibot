const Discord = require("discord.js");
 
exports.run = (bot, message, args) => {
 
    if (!message.member.hasPermission("ADMINISTRATOR")) return message.reply(`sem permissao`)
 
    let membro = message.mentions.users.first()
    if (!membro) return message.reply(`mencione o membro`)
 
    let motivo = args.slice(1).join(" ");
    if (!motivo) return message.reply(`escreva a resposta do ticket`)
 
    let imbed = new Discord.RichEmbed()
 
    .setTitle(`Resposta Do Ticket - ${membro.username}`)
    .setColor('BLUE')
    .setFooter(`Staff responsavel: ${message.author.username}`, message.author.avatarURL)
    .setDescription(motivo)
 
    if(message.deletable) message.delete();
    membro.send(imbed)
    message.channel.send(`:thumbsup: Respósta inviada ao usuario do ticket!`)
 
}
 
exports.help = {
    name: 'resposta'
}