const Discord = require("discord.js");
const bot = new Discord.Client();

exports.run = (client, message, args) => {
    var embed = new Discord.RichEmbed()
    .setAuthor(client.user.username, client.user.avatarURL)
    .setTitle("Olá, Eu sou a Loli, Sou uma bot criada para ajudar Jogadores Com Suas Duvidas, e A staff na Moderação De Usuarios, estou na minha fase beta, mas já pode usar alguns dos meus comandos! /cmd")
    .setDescription("Fui Criada pelo jhow2")


    .setColor("#df41ca")
    message.channel.sendEmbed(embed);
    if(message.deletable) message.delete();
}