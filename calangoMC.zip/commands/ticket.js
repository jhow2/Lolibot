const Discord = require('discord.js');
const moment = require('moment');

const cooldown = new Set();
module.exports.run = async (bot, msg) => {
    let args = msg.content.split(' ').slice(1).join(' ');
    msg.delete();
    if (cooldown.has(msg.author.id && msg.guild.id)) {
        return msg.reply('**[COOLDOWN]** ticket inviado aguarde **30 segundos** Cooldown!');
    }
    if (args.length < 1) {
        return msg.reply(`Você deve me dar algo para relatar primeiro ${msg.author}`);
    }

    cooldown.add(msg.author.id && msg.guild.id);
    setTimeout(() => {
        cooldown.delete(msg.author.id && msg.guild.id);
    }, 30);
    let guild = msg.guild;
    const cnl = bot.channels.get('697960211612434502');
    msg.reply(`Olá, nós recebemos o seu relatório! Responderemos o mais breve possível!`);
    const embed2 = new Discord.RichEmbed()
    .setAuthor (`Ticket de ${msg.author.tag}`, msg.author.displayAvatarURL)
    .addField ('Ticket:', `** Autor do ticket: ** ${msg.author.tag} \ n ** Servidor: ** ${guild.name} \ n ** Ticket completo: ** ${args } `)
    .setThumbnail (msg.author.displayAvatarURL)
    .setFooter (`${moment (). format ('MMMM Do AAAA, h: mm: ss a')}`)
    .setColor (16711728);
    msg.channel.send({embed2});
    const embed = new Discord.RichEmbed()
    .setAuthor (`Ticket de ${msg.author.tag}`, msg.author.displayAvatarURL)
    .addField ('Ticket:', `** Autor do ticket: ** ${msg.author.tag} \ n ** Servidor: ** ${guild.name} \ n ** Ticket completo: ** ${args } `)
    .setThumbnail (msg.author.displayAvatarURL)
    .setFooter (`${moment (). format ('MMMM Do AAAA, h: mm: ss a')}`)
    .setColor (16711728);
    cnl.send({embed})
    cnl.membro.send(embed)
  .catch(e => logger.error(e))
};

module.exports.help = {
    name: 'Ticket'
};