const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {
    let muteRole = message.guild.roles.find("name", "Silenciado")
    let member = message.mentions.members.first()
    if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("Você não tem permissão para executar este comando!")
    if(!member) return message.channel.send(`Mencione o membro que quer desmutar.`)
     else{
         member.removeRole(muteRole)
            let embed = new Discord.RichEmbed()
            .setTitle(`Membro Desmutado`, `${member}`)
            .addField(`Desmutado por:`, `${message.author}`)

        if(message.deletable) message.delete();
        message.channel.send(embed)
     }
}