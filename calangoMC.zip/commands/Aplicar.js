    module.exports.run = async (client, message, args) => {
    message.delete().catch()
    const guildArray = client.guilds.map((guild) => {
    return `Está pensando em virar staff????

    Este Formulário Especificico da Rede Calango 
    Obs:Tag designada a tag Ajudante!!!


    Formulário: https://forms.gle/xWLLvc33bsBLqHze6\n\n`
    })

    await message.author.send(`\`\`\`${guildArray.join("\n")}\`\`\``)
    if(message.deletable) message.delete();
    return message.channel.send(`${message.author} Mandei O Formulário no seu privado!`)
}

module.exports.help = {
    name: "Forms"
}