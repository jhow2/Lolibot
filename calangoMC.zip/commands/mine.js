const {Client, RichEmbed } = require('discord.js')
 
const bot = new Client()
 
const ping = require('minecraft-server-util')
 
const token = 'Njc5NDg3Njc4MzI4MDc4Mzc2.XofDpQ.ZCsTsT1HZPIphKnJTpUY_6VcInE'
 
const PREFIX = '/'
 
bot.on('ready', () =>{
    console.log('Bot has come online.')
})
 
bot.on('message', message =>{
 
    let args = message.content.substring(PREFIX.length).split(' ')
 
    switch(args[0]){
        case 'infoip':
 
            if(!args[1]) return message.channel.send('Digite um Ip de servidor Minecraft')
 
            ping(args[1], (error, reponse) =>{
                if(error) throw error
                const Embed = new RichEmbed()
                .setTitle('Servidor Status')
                .addField('Servidor IP', reponse.host)
                .addField('Servidor Versão', reponse.version)
                .addField('Online Players', reponse.onlinePlayers)
                .addField('Jogadores maximo ', reponse.maxPlayers)
               
                if(message.deletable) message.delete();
                message.channel.send(Embed)
            })
        break
 
    }
 
})
 
bot.login(token)