const Discord = require("discord.js");

module.exports.run = (bot, message, args) => {

    function checkBots(guild) {
        let botCount = 0; // This is value that we will return
        guild.members.forEach(member => { // We are executing this code for every user that is in guild
          if(member.user.bot) botCount++; // If user is a bot, add 1 to botCount value
        });
        return Message.Channel.send("Você não podes ultilizar este comando Aqui bobinho")
        return botCount; // Return amount of bots
      }

    var embed = new Discord.RichEmbed()
        .setTitle("Minhas Função!! Está Em Beta")
        .setDescription("Use Somente em #⚙┋comandos Os meus comandos Querido(a)")
        .addField("/fantasy", "este Comando Foi feito somente ao pessoal da fantasy hosting para Divulgar suas promoção!!")
        .addField("/ping", "Comando para veres o meu e o teu ping!")
        .addField("/mine", "Este comando habilita o /infoip Obs Não será todos os servidores que irá funcionar tem uma Limitação por estar em faze beta!!")
        .addField("/infoip", "Infoip e para saber o servidor de minecraft online com Jogadores e A verção motd e muito mais!!")
        .addField("/ticket","Adicionado Obs O ticket que Você criar teria 2 replica 1 para Ti e a  outra para staff Porfavor esteja com o privado liberado o ticket respondido vai via Privado com o usuario através de min!!!")
        .addField("/info", "Comando para saberes mais sobre mim!")
        .addField("avatar", "Para Pegar O Avatar de Alguem")
        .addField("/serverinfo", "Comando para veres as informações do servidor!")
        .addField("/ban,/warn,/kick,/aviso,/cc", "Comandos para Staff Banimentos, kicks, warns, Para Limparchat, e avisar!")
        .addField("/covid19", "Comando para Saber a prenvenção Contra o Covid19!")     
        .addField("/Votaçao", "Comando para Iniciar uma Votação!")
        .addField("/divulgar", "Exclusivo a Youtuber está Disponivel Novamente Obs: Use so em Divulgação!")
        .addField("/online", "Para saber o tempo Online de Min!")
        .addField("/Sugerir", "Para Fazer Uma Sugestão Para Adicionar em bot Ou Em Servidor minecraft!")
        .addField("/Carfy" ,"Para saber o status do servidor com O carfy")



        .setColor("#df41ca")
        .setThumbnail(bot.user.avatarURL)
        message.channel.sendEmbed(embed);
        if(message.deletable) message.delete();

}