//avatar

const Discord = require("discord.js");
 
exports.run = (bot, message, args) => {
 
      let member = message.mentions.users.first() || message.author;
    
      let embed = new Discord.RichEmbed()
 
    .setColor('PINK')
    .setTitle(`${message.guild.name}`)
    .setDescription("[Link de Download](" + member.displayAvatarURL + ")")
    .setImage(member.displayAvatarURL)
 
    message.reply(embed)
 
}


