const Discord = require("discord.js");
 
exports.run = (bot, message, args) => {
 
    if (!message.member.hasPermission("ADMINISTRATOR")) return message.reply(`infelizmente não tens permissão para executar esse comando!!`)
 
    message.channel.send(`Qual canal queres que eu informe o anúncio?`).then(msg => {
        let cp = message.channel.createMessageCollector(x => x.author.id == message.author.id, {max: 1})
        .on('collect', c => {
            canal = c.mentions.channels.first()
            if (!canal) {
                message.reply(`Diz me um canal!`)
            } else {
                message.channel.send(`Qual a mensagem queres que eu anucie?`).then(msg2 => {
                    let cl = message.channel.createMessageCollector(x => x.author.id == message.author.id, {max: 1})
                    .on('collect', c => {
                        desc = c.content
                   
                        message.channel.send(`Escolhe um título!`).then(msg3 => {
                            let ck = message.channel.createMessageCollector(x => x.author.id == message.author.id, {max: 1})
                            .on('collect', c => {
                                title = c.content
 
                                message.channel.send(`Anunciei no ${canal} o teu anúncio.`)
 
                                let embed = new Discord.RichEmbed()
 
                                .setColor('#a628ec')
                                .setFooter(`Comando efetuado por: ${message.author.username}`, message.author.avatarURL)
                                .setTitle(title)
                                .setDescription(desc)
 
                                canal.send(embed)
 
                            })
                        })
                    })
                })
            }
        })
    })
 
}