      module.exports.run = async (client, message, args) => {
        if(!message.member.hasPermission("ADMINISTRATOR")) return message.reply("Você não pode usar esse comando.")
        message.delete().catch()

        const guildArray = client.guilds.map((guild) => {
        return `Comandos staff!!!!
               
        Comandos ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
        Staff Presta atenção!!!
  
        Banimentos /ban @user Motivo
        sistema de mute /mute @user  1s,m,d,h,y 
        s=Segundos,m=minutos,d=dias,h,horas,y=anos e Obs Coloque o motivo antes
        
        
        Kick /kick @user Motivo
        /warn nick0 motivo 1/3 2/3 3/3 e mais o ban junto com o motivo do warn

        
        para responder Um ticket Ultilize
        /reponder User ticket da resposta

        Sistema de Votação
        para Ultilizar de 
        /votacao
        
  
  
        Avisos no chat de antes 
        /aviso Reformulado use em #configuração Bot Nos chat da staff 
        Te dará as seguintes especificação 

        dando /aviso antes
        escolha o Chat que irá avisar
        Qual a mensagem escreva como aviso 
        escolha o Titulo com a mensagem ex: Eu estou divulgando tal coisa
        e aparecerá uma mensagem de confirmação Que sua mensagem foi inviada no tal chat com o anuncio


        Obs: use antes
  
        Marcações: 
        ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ `
        })
        if(message.deletable) message.delete();
        await message.author.send(`\`\`\`${guildArray.join("\n")}\`\`\``)
        return message.channel.send(`${message.author} Mandei Os meus comandos na staff no seu privado!`)
    }
    
    module.exports.help = {
        name: "Comandos staff"
    }