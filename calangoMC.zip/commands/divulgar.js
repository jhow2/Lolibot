const Discord = require('discord.js')

module.exports = {
    run: (client, message, args) => {

        message.delete().catch()

        let splitarg = args.join(" ").split(" / ")
        let titulo = splitarg[0]
        let anuncio = splitarg[1]

        if(titulo){
            let fala = args.slice(0).join (" ");

            if(message.deletable) message.delete();
        
            message.channel.send(fala);
            return
        }

        if(anuncio){
            let fala = args.slice(0).join (" ");

            if(message.deletable) message.delete();
        
            message.channel.send(fala);
            return
        }

        let anuncioembed = new Discord.RichEmbed()
        .setColor("#FF9900")
        .addField(`${titulo}`, `**${anuncio}**`)
        .setFooter(`Anuncio feito por ${message.author.tag}`)
        .setTimestamp();

        message.channel.send(anuncioembed)
    }
}
