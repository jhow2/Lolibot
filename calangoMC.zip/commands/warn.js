const Discord = require("discord.js");
 
exports.run = (bot, message, args) => {
 
    if (!message.member.hasPermission("ADMINISTRATOR")) return message.reply(`sem permissao`)
 
    let membro = message.mentions.users.first()
    if (!membro) return message.reply(`mencione um membro`)
 
    let motivo = args.slice(1).join(" ");
    if (!motivo) return message.reply(`escreva um motivo`)
 
    let embed = new Discord.RichEmbed()
 
    .setTitle(`WARN - ${membro.username}`)
    .setColor('RED')
    .setFooter(`Staff responsavel: ${message.author.username}`, message.author.avatarURL)
    .setDescription(motivo)
 
    if(message.deletable) message.delete();
    membro.send(embed)
    message.channel.send(`:warning: Warn Aplicado sucesso!`)
 
}
 
exports.help = {
    name: 'warn'
}