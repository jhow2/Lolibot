const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {
    if(!message.member.hasPermission('BAN_MEMBERS')) return message.reply("infelizmente não tem permissão para executar esse comando!!")
    let member = message.mentions.members.first()
    if(!member)
      return message.reply("esse usuário não existe!")
    if(!member.bannable)
      return message.reply("eu não posso banir esse usuário por ter um cargo superior.")
    let reason = args.slice(1).join(' ')
    if(!reason) reason = "Nenhuma razão fornecida"
    await member.ban(reason)
      .catch(error => message.reply(`desculpa ${message.author} não consegui banir o usuário devido ao: ${error}`))

      let pEmbed = new Discord.RichEmbed()
          .setTitle(":pick: Ban")
          .addField("Membro Banido:", `${member.user.tag}`)
          .addField("Banido por:", `${message.author.tag}`)
          .addField("Motivo:", `${reason}`)
          .setFooter(`${message.author.tag}`, message.author.displayAvatarURL)
          .setColor("DARK_RED").setTimestamp()

          if(message.deletable) message.delete();
          message.channel.send(pEmbed);
          
}

module.exports.help = {
    name: "ban"
}