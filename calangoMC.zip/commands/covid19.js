module.exports.run = async (client, message, args) => {
    const guildArray = client.guilds.map((guild) => {
    return ` ⚠️Alerta de COVID-19⚠️

           Coronavírus |COVID-19|

                    5 Prevenção Contra 
                     SIGA AS 5 DICAS
             Ajude a combater o coronavírus
             1 MÃOSLavar frequentemente
             2 COTOVELO Usar para cobrir a tosse
             3 ROSTO Não tocar
             4 ESPAÇO Manter a distância segura
             5 CASA Não sair, se possível


    Tratamento!

    Não há nenhum medicamento específico para tratar ou prevenir o coronavírus |COVID-19|. 
    Algumas pessoas podem precisar da ajuda de aparelhos para respirar.
    Autocuidados

    1 Se você apresentar sintomas leves, fique em casa até se recuperar. Para aliviar os sintomas:
      descanse e durma;
    2 mantenha o corpo aquecido:
    3 beba bastante líquido:
    4 use um umidificador de ar ou tome um banho quente para aliviar a tosse e a dor de garganta.

    Sintomas!

    O coronavírus |COVID-19| se caracteriza por sintomas leves, como nariz escorrendo, dor de 
    garganta, tosse e febre. A doença pode ser mais grave para algumas pessoas, causando 
    pneumonia ou dificuldade para respirar.
    Em casos mais raros, ela pode ser fatal. Idosos e pessoas com outras condições médicas 
    como asma, diabetes e doença cardíaca| são mais vulneráveis a quadros graves.
    Possíveis sintomas:

    1 Nariz escorrendo
    2 Dor de garganta
    3 Tosse
    4 Febre
    5 Dificuldade para respirar |em casos graves|
    
    Marcações: @everyone @here`
    })

    await message.author.send(`\`\`\`${guildArray.join("\n")}\`\`\``)
    if(message.deletable) message.delete();
    return message.channel.send(`${message.author} Mandei as Recomendação para evitar o covid19 no seu privado!`)
}

module.exports.help = {
    name: "covid19"
}